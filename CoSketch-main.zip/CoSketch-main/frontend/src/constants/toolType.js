export const toolTypes = {
    RECTANGLE: "RECTANGLE",
    CIRCLE: "CIRCLE",
    LINE: "LINE",
    PENCIL: "PENCIL",
    TEXT: "TEXT",
    SELECTION: "SELECTION"
};
  