export const actions = {
    DRAWING: "DRAWING",
    WRITING: "WRITING",
    MOVING: "MOVING",
    RESIZING: "RESIZING"
};
  