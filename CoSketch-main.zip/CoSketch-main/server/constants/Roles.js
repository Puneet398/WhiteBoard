const Roles = {
    ADMIN: 'admin',
    USER: 'user',
};

module.exports = Roles;